<h1>GETs e Posts</h1>
<ul>
<li>desconto-cliente [GET]</li>
<li>estoque-atual-ingrediente [GET]</li>
<li>[Inativo] lucro-geral-venda [GET]</li>
<li>[Inativo] lucro-geralproduto [GET]</li>
<li>meio-pagamento [GET]</li>
<li>produtos-restantes [GET]</li>
</ul>
<h1>Pendências:</h1>
<ul>
<li>Funcionalidade: Lucro Geral por Venda. Colocar nomes certos dos Get's em LucroGeralVendaDTO, adicionar a Query em VendaRepository e "descomentar" em LucroGeralVendaController</li>
<li>Funcionalidade: Lucro por produto. Colocar nomes certos dos Get's em LucroProdutoDTO, adicionar a Query em VendaRepository e "descomentar" em LucroProdutoController</li>
<li>Funcionalidade: fazer tudo de lucro em determinado período (lidar com passada de parâmetros)</li>
</ul>