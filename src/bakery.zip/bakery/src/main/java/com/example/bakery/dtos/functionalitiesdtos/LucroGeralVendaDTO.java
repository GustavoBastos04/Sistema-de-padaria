package com.example.bakery.dtos.functionalitiesdtos;

public interface LucroGeralVendaDTO {
}
