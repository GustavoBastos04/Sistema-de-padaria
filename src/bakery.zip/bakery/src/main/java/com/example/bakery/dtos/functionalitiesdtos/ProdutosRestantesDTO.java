package com.example.bakery.dtos.functionalitiesdtos;

public interface ProdutosRestantesDTO {
    String getNome();
    Integer getQuantidade();
}
