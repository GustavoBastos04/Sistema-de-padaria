package com.example.bakery.dtos.functionalitiesdtos;

public interface LucroProdutoDTO {
}
