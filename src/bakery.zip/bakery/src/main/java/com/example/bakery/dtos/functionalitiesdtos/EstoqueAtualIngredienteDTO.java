package com.example.bakery.dtos.functionalitiesdtos;

public interface EstoqueAtualIngredienteDTO {
    String getNome();
    Integer getQuantidade();
}
