package com.example.bakery.dtos.functionalitiesdtos;

public interface FornecedorDTO {
    String getCnpj();
    String getNome();
    String getTelefone();
    String getEmail();
    String getCep();
    String getEndereco();
    String getCidade();
    String getUf();
}
