package com.example.bakery.dtos.functionalitiesdtos;

public interface ClienteDTO {
    String getCpf();
    String getNome();
    String getTipo_de_assinatura();
    String getTelefone();
    String getEmail();
    String getCep();
    String getEndereco();
    String getCidade();
    String getUf();
}
